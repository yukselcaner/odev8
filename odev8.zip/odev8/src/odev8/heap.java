package odev8;

public class heap {
	public int diziBoyutu(String sayilar) {
		int diziBoyutu = 0;
		for (int i = 0; i < sayilar.length(); i++) {
			if (sayilar.substring(i, i + 1).equals(",")) {
				diziBoyutu++;
			}
		}
		diziBoyutu++;
		return diziBoyutu;
	}

	public int[] diziOlustur(String sayilar, int[] dizi) {
		int strIndex = 0, diziIndex = 0;
		int virgul = 0;
		for (int i = 0; i < sayilar.length(); i++) {
			if (sayilar.substring(i, i + 1).equals(",")) {
				dizi[diziIndex] = Integer.valueOf(sayilar.substring(strIndex, i));
				diziIndex++;
				strIndex = i + 1;
				virgul = i;
			}
		}
		dizi[diziIndex] = Integer.valueOf(sayilar.substring(virgul + 1, sayilar.length()));
		return dizi;
	}

	public boolean heapMi(int[] dizi) {
		for (int i = 0; i < dizi.length - 3; i++) {
			if (dizi.length-1>=i*3+1 && dizi[i] > dizi[i * 3 + 1]) {
				return false;
			}
			if (dizi.length-1>=i*3+2 && dizi[i] > dizi[i * 3 + 2]) {
				return false;
			}
			if (dizi.length-1>=i*3+3 && dizi[i] > dizi[i * 3 + 3]) {
				return false;
			}
		}
		return true;
	}
	public int[] heapYap(int[] dizi) {	
		int[] heap = new int[dizi.length];
		int heapIndex = 0;
		for(int i=0;i<dizi.length;i++) {
			heap[heapIndex] = dizi[i];
			for(int x=heapIndex;x>0;x=(x-1)/3) {
				if(heap[x]<heap[(x-1)/3]) {
					int tmp = heap[x];
					heap[x] = heap[(x-1)/3];
					heap[(x-1)/3] = tmp;
				}
			}
			heapIndex++;
		}
		return heap;
	}
	public void yazdir(int[] dizi) {
		System.out.print("[");
		for(int i=0; i<dizi.length;i++) {
			System.out.print(dizi[i] +",");
		}
		System.out.println("]");
	}
}
