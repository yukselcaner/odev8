package odev8;
import java.util.Scanner;

/**
 * 
 * @author Yüksel Caner MÜLAZIMOĞLU - 02210201034
 *
 */

public class Main {
	public static void main(String[] args) {
		System.out.println("Sayilari aralarinda virgul olacak sekilde giriniz.");
		String sayilarStr = new Scanner(System.in).nextLine();
		
		heap heap = new heap();
		
		int[] sayilar = new int[heap.diziBoyutu(sayilarStr)];
		sayilar = heap.diziOlustur(sayilarStr, sayilar);
		
		if(heap.heapMi(sayilar)) {
			System.out.println("3'lü min heaptir");
		}
		else {
			System.out.println("heap değildir");
			sayilar = heap.heapYap(sayilar);
			heap.yazdir(sayilar);
		}
	}
}
